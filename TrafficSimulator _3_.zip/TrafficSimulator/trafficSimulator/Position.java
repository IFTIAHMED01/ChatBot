public class Position {

	private TrafficElement trafficElement;
	private Point coordinate;


	public TrafficElement getTrafficElement() {
		return trafficElement;
	}

	public void setTrafficElement(TrafficElement trafficElement) {
		this.trafficElement = trafficElement;
	}

	public Point getCoordinate() {
		return coordinate;
	}

	public void setCoordinate(Point point) {
		this.coordinate = point;
	}
}