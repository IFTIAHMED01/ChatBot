import java.util.ArrayList;
import static java.lang.System.exit;

/**
 * TRAFFIC SIMULATOR
 *
 * COSC 3P91 - Assignment 2
 * Project done by:
 *
 * Akshar Patel (6581599)
 * Ifti Ahmed (6559348)
 *
 * Submitted to Robson De Grande
 * for COSC 3P91 at Brock University
 *
 */

public class Main {

}