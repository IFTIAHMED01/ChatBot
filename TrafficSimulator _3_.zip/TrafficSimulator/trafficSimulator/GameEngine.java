import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

import static java.lang.Math.abs;
import static java.lang.System.exit;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

public class GameEngine extends Thread {

    static Player player;

    /**
     * prints game rules
     */
    public static void printRules(PrintWriter cout) {
        cout.println("Rules:");
        cout.println("Press \"W\" to move forward.");
        cout.println("Press \"S\" to brake/move downward.");
        cout.println("Press \"A\" to move turn right/change lane to right.");
        cout.println("Press \"D\" to move turn left/change lane to left.");
        cout.println("\n\"l\" represents a lane on the map, \"V\" for Player's vehicle and \"B\" for Bot's vehicle");
        cout.println("Here a sample representation of the map");
    }

    /**
     * Generates a map with 10 road segments, each road segment has 2 lanes
     *
     * @param graph
     * @param trafficNetwork
     */
    public static void makeMap(Graph graph, TrafficNetwork trafficNetwork) {
        trafficNetwork.makeVerticalRoad(10, 1, 9, graph);
        trafficNetwork.makeVerticalRoad(10, 6, 9, graph);
        trafficNetwork.makeVerticalRoad(10, 15, 9, graph);
        trafficNetwork.makeVerticalRoad(10, 25, 9, graph);
        trafficNetwork.makeVerticalRoad(10, 35, 9, graph);
        trafficNetwork.makeVerticalRoad(10, 44, 9, graph);
        trafficNetwork.makeVerticalRoad(10, 49, 9, graph);
        trafficNetwork.makeHorizontalRoad(50, 0, 1, graph);
        trafficNetwork.makeHorizontalRoad(50, 0, 5, graph);
        trafficNetwork.makeHorizontalRoad(50, 0, 9, graph);
    }

    /**
     * method that prompts user to select a vehicle
     */
    public static Vehicle selectVehicle(PrintWriter cout, BufferedReader cin) throws IOException {

        int c = -1;
        cout.println("""
                Select your vehicle
                1. Car
                2. Bus
                3. Truck
                """);
        while (true) {
            try {
                c = Integer.parseInt(cin.readLine());
                if (c == 1 || c == 2 || c == 3) break;
                throw new InvalidInputException("Invalid input.");
            } catch (Exception ex) {
                cout.println("Invalid input.");
            }
        }


        if (c == 1) {
            Car vehicle = new Car();
            int d = -1;
            while (d < 2 || d > 4) {
                cout.println("Select number of doors (2-4) for your car: ");
                d = Integer.parseInt(cin.readLine());
            }
            vehicle.setNumberOfDoors(d);
            return vehicle;

        } else if (c == 2) {
            Bus vehicle = new Bus();
            int p = -1;
            while (p < 1 || p > 40) {
                cout.println("Select number of passengers (0-40) for your bus: ");
                p = Integer.parseInt(cin.readLine());
            }
            vehicle.setNumberOfPassengers(p);
            return vehicle;
        } else {
            Truck vehicle = new Truck();
            double w = -1.0;
            while (w < 0.0 || w > 10000.0) {
                cout.println("Select weight of cargo (in kgs) for your truck: ");
                w = Double.parseDouble(cin.readLine());
            }
            vehicle.setCargo(w);
            return vehicle;
        }

    }

    /**
     * Method initializes 4 AI bots that are placed on the map
     *
     * @param graph
     * @return
     */
    public static ArrayList<Player> initializeBots(Graph graph) {

        Player bot0 = new Player(new Car());
        Player bot1 = new Player(new Truck());
        Player bot2 = new Player(new Bus());
        Player bot3 = new Player(new Vehicle() {
            @Override
            public Double getSize() {
                return super.getSize();
            }

            @Override
            public void setSize(Double size) {
                super.setSize(size * 100.0);
            }
        });
        bot3.getVehicle().setSize(200.0);

        ArrayList<Point> initialPointsList = new ArrayList<>(Arrays.asList(new Point(15, 9), new Point(25, 9), new Point(35, 9), new Point(45, 9)));

        ArrayList<Player> bots = new ArrayList<>(Arrays.asList(bot0, bot1, bot2, bot3));

        for (int i = 0; i < 4; i++) {
            MovementStatus movementStatus = new MovementStatus(initialPointsList.get(i), null, null);
            bots.get(i).getVehicle().setMovementStatus(movementStatus);
            int x = bots.get(i).getVehicle().getMovementStatus().getPoint().getX();
            int y = bots.get(i).getVehicle().getMovementStatus().getPoint().getY();
            Node n = graph.getNode(x, y, graph.getAllNodes());
            bots.get(i).getVehicle().getMovementStatus().setPoint(n.getPoint());
            n.setTrafficElement(TrafficElement.BOT);
        }

        graph.setBots(bots);
        return bots;
    }

    /**
     * Method moves all bots on the map to the next available point on the map
     *
     * @param graph
     * @return
     */
    public static boolean moveBots(Graph graph, PrintWriter cout, BufferedReader cin) {

        for (int i = 0; i < graph.getBots().size(); i++) {

            Point p1 = graph.getBots().get(i).getVehicle().getMovementStatus().getPoint();
            Node n1 = graph.getNode(p1.getX(), p1.getY(), graph.getAllNodes());

            Player bot = graph.getBots().get(i);

            if (n1.getNorth() != null) {
                bot.setLastMove(Direction.NORTH);
            } else if (n1.getSouth() != null) {
                bot.setLastMove(Direction.SOUTH);
            } else if (n1.getWest() != null) {
                bot.setLastMove(Direction.WEST);
            } else if (n1.getEast() != null) {
                bot.setLastMove(Direction.EAST);
            }
            try {
                if (!bot.makeMove(graph, cout, cin)) {
                    return false;
                }
            } catch (InvalidInputException | IOException | InterruptedException e) {
                e.printStackTrace();
            }
        }

        return false;
    }

}
