public interface VehicleFactory {

    public String getColor();

    public void setColor(String color);

    public Double getSize();

    public void setSize(Double size);

    public Double getWeight();

    public void setWeight(Double weight);

    public Double getMaxSpeed();

    public void setMaxSpeed(Double maxSpeed);

    public DamageStatus getDamageStatus();

    public void setDamageStatus(DamageStatus damageStatus);

    public MovementStatus getMovementStatus();

    public void setMovementStatus(MovementStatus movementStatus);

}
