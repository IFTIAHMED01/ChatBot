//Singleton class

import java.io.PrintWriter;

public class Singleton {

    private static final Singleton instance = new Singleton();

    private Singleton(){}

    public static Singleton getInstance(){
        return instance;
    }

    public void printMap(int x, int y, Graph graph, PrintWriter cout) {
        for (int i = 0; i < x; i++) {
            for (int j = 0; j < y; j++) {
                //cout.print("(" + getNode(j, i, allNodes).point.getX() + ", " + getNode(j, i, allNodes).point.getY() + ")\t\t");

                Node curr = graph.getNode(j, i, graph.getAllNodes());
                TrafficElement n = curr.getTrafficElement();

                if (n == null){
                    cout.print(" ");
                }
                else {

                    switch (n) {
                        case VEHICLE -> cout.print("V");
                        case BOT -> cout.print("B");
                        case LANE -> cout.print("l");
                        case CURB -> {
                            if (curr.getNorth() != null || curr.getSouth() != null) {
                                cout.print("|");
                            } else cout.print("-");
                        }
                        case DIVIDER -> {
                            if (curr.getNorth() != null || curr.getSouth() != null) {
                                cout.print("|");
                            } else cout.print("-");
                        }
                        case INTERSECTION -> cout.print("o");
                    }
                }

            }
            cout.println();
        }
    }

}
