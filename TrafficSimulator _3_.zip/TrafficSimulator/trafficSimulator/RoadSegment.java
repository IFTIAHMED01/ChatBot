import java.util.ArrayList;

public class RoadSegment {
	public RoadSegment() {
	}

	private ArrayList<Intersection> intersections = new ArrayList<>();
	private ArrayList<Lane> lanes = new ArrayList<>();

	public ArrayList<Intersection> getIntersections() {
		return intersections;
	}

	public void setIntersections(ArrayList<Intersection> intersections) {
		this.intersections = intersections;
	}

	public ArrayList<Lane> getLanes() {
		return lanes;
	}

	public void setLanes(ArrayList<Lane> lanes) {
		this.lanes = lanes;
	}


//  point is the starting point of the curb at the starting point of the right lane
//	public void addRoad(@NotNull Point point, int length, @NotNull ArrayList<Lane> lanes, Graph graph, boolean divider, Direction direction){
//
//		int x = point.getX();
//		int y = point.getY();
//		int numLanes = lanes.size();
//		if(divider) numLanes++;
//
//		Node node;
//
//		for (int i = 0; i < length; i++) {
//
//			if (direction == Direction.NORTH){
//				//curb
//				node  = graph.getNode(x, y-i, graph.allNodes);
//				node.trafficElement = TrafficElement.CURB;
//				node.north = graph.getNode(x, y-i-1, graph.allNodes);
//
//				//lane
//				for (int j = 1; j < lanes.size()+1; j++) {
//					node = graph.getNode(x-j, y-i, graph.allNodes);
//
//				}
//			}
//
//
//		}
//
//
//	}



}