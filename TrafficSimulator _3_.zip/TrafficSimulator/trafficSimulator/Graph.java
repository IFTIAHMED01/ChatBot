import java.io.PrintWriter;
import java.util.ArrayList;

public class Graph {

    int x;
    int y;
    private ArrayList<Node> allNodes = new ArrayList<>();
    private ArrayList<Node> allInterNodes;
    private ArrayList<Player> bots;

    public ArrayList<Node> getAllNodes() {
        return allNodes;
    }

    public void setAllNodes(ArrayList<Node> allNodes) {
        this.allNodes = allNodes;
    }

    public ArrayList<Node> getAllInterNodes() {
        return allInterNodes;
    }

    public void setAllInterNodes(ArrayList<Node> allInterNodes) {
        this.allInterNodes = allInterNodes;
    }

    public ArrayList<Player> getBots() {
        return bots;
    }

    public void setBots(ArrayList<Player> bots) {
        this.bots = bots;
    }

    /**
     * Constructor. created a map like x*y graph
     * @param x
     * @param y
     */
    public Graph(int x, int y) {

        this.x = x;
        this.y = y;
        this.bots = null;
        this.allInterNodes = null;

        for (int i = 0; i < x; i++) {
            for (int j = 0; j < y; j++) {
                Node node = new Node(new Point(i, j));
                allNodes.add(node);
            }
        }
    }

    /**
     * Copy constructor
     * @param graph
     */
    public Graph(Graph graph){
        this.x = graph.x;
        this.y = graph.y;
        this.allNodes = graph.allNodes;
        this.allInterNodes = graph.allInterNodes;
        this.bots = graph.bots;
    }

    /**
     * Returns the node on point (x, y)
     * @param x
     * @param y
     * @param list
     * @return
     */
    public Node getNode(int x, int y, ArrayList<Node> list) {
        for (Node n : list) {
            if (n.getPoint().getX() == x && n.getPoint().getY() == y) return n;
        }
        return null;
    }

    public void printMap(int x, int y, PrintWriter cout) {
        for (int i = 0; i < x; i++) {
            for (int j = 0; j < y; j++) {
                //cout.print("(" + getNode(j, i, allNodes).point.getX() + ", " + getNode(j, i, allNodes).point.getY() + ")\t\t");

                Node curr = getNode(j, i, allNodes);
                TrafficElement n = curr.getTrafficElement();

                if (n == null){
                    cout.print(" ");
                }
                else {

                    switch (n) {
                        case VEHICLE -> cout.print("V");
                        case BOT -> cout.print("B");
                        case LANE -> cout.print("l");
                        case CURB -> {
                            if (curr.getNorth() != null || curr.getSouth() != null) {
                                cout.print("|");
                            } else cout.print("-");
                        }
                        case DIVIDER -> {
                            if (curr.getNorth() != null || curr.getSouth() != null) {
                                cout.print("|");
                            } else cout.print("-");
                        }
                        case INTERSECTION -> cout.print("o");
                    }
                }

            }
            cout.println();
        }
    }

//    public void linkGraph() {
//        for (int i = 0; i < this.x; i++) {
//            for (int j = 0; j < this.y; j++) {
//                Node node;
//                node = getNode(i, j, this.allNodes);
//                if ((j - 1) >= 0) node.north = getNode(i, j - 1, this.allNodes);
//                else node.north = null;
//                if ((i - 1) >= 0) node.west = getNode(i - 1, j, this.allNodes);
//                else node.west = null;
//                if ((j + 1) < this.y) node.south = getNode(i, j + 1, this.allNodes);
//                else node.south = null;
//                if ((i + 1) < this.x) node.east = getNode(i + 1, j, this.allNodes);
//                else node.east = null;
//            }
//        }
//    }
}
