public class Node {

    private Node north;
    private Node west;
    private Node south;
    private Node east;
    private Point point;
    private Vehicle vehicle;
    private boolean isIntersection;
    private TrafficElement trafficElement;

    public Node getNorth() {
        return north;
    }

    public void setNorth(Node north) {
        this.north = north;
    }

    public Node getWest() {
        return west;
    }

    public void setWest(Node west) {
        this.west = west;
    }

    public Node getSouth() {
        return south;
    }

    public void setSouth(Node south) {
        this.south = south;
    }

    public Node getEast() {
        return east;
    }

    public void setEast(Node east) {
        this.east = east;
    }

    public Point getPoint() {
        return point;
    }

    public void setPoint(Point point) {
        this.point = point;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    public boolean isIntersection() {
        return isIntersection;
    }

    public void setIntersection(boolean intersection) {
        isIntersection = intersection;
    }

    public TrafficElement getTrafficElement() {
        return trafficElement;
    }

    public void setTrafficElement(TrafficElement trafficElement) {
        this.trafficElement = trafficElement;
    }

    public Node(Point point) {
        this.point = point;
        this.north = null;
        this.west = null;
        this.south = null;
        this.east = null;
        vehicle = null;
        trafficElement = null;
        isIntersection = false;
    }

}
