import java.net.*;
import java.io.*;
import java.util.Scanner;

import static java.lang.Thread.sleep;

public class Client {
    public static void main(String[] args) {
        String hostName = "localhost";
        int portNumber = 1024;
        try (
                Socket conn = new Socket(hostName, portNumber);
                PrintWriter sockOut = new PrintWriter(conn.getOutputStream(), true);
                BufferedReader sockIn = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                Scanner termIn = new Scanner(System.in);
        ) {
            while (true) {

                Thread.sleep(10);
                while (sockIn.ready()){
                    String fromServer = sockIn.readLine();
                    System.out.println(fromServer);
                }

                String fromUser = termIn.nextLine();
                sockOut.println(fromUser);

            }
        } catch (UnknownHostException e) {
            System.out.println("I think there's a problem with the host name.");
        } catch (IOException e) {
            System.out.println("Had an IO error for the connection.");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
