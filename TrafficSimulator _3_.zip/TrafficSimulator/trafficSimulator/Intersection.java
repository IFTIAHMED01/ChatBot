import java.util.ArrayList;

public class Intersection {

	private ArrayList<RoadSegment> roads;

	public ArrayList<RoadSegment> getRoads() {
		return roads;
	}

	public void setRoads(ArrayList<RoadSegment> roads) {
		this.roads = roads;
	}

	public ArrayList<Node> addAllInterNodes(Graph graph){

		ArrayList<Node> interList = new ArrayList<>();
		ArrayList<Node> allNodes = graph.getAllNodes();

		for (Node n :
				allNodes) {
			int counter = 0;
			if (n.getNorth()!=null)counter++;
			if (n.getWest()!=null)counter++;
			if (n.getSouth()!=null)counter++;
			if (n.getEast()!=null)counter++;

			if(counter>1){
				interList.add(n);
			}
		}

		return interList;

	}
}