import java.net.*;
import java.io.*;

public class    ThreadedServer {
    public static void main(String[] args) {
        int portNumber = 1024;
        try (
                ServerSocket serverSocket = new ServerSocket(portNumber);
        ) {
            Socket client1=serverSocket.accept();
            new ConnectionThread(client1).start();
        } catch (IOException e) {
            System.out.println("Exception caught when trying to listen on port " + portNumber + " or listening for a connection");
            System.out.println(e.getMessage());
        }
    }
}