public class MovementStatus {

	private Point point;
	private Double speed;
	private Direction direction;

	public MovementStatus(Point point, Double speed, Direction direction) {
		this.point = point;
		this.speed = speed;
		this.direction = direction;
	}

	public Point getPoint() {
		return point;
	}

	public void setPoint(Point point) {
		this.point = point;
	}

	public Double getSpeed() {
		return speed;
	}

	public void setSpeed(Double speed) {
		this.speed = speed;
	}

	public Direction getDirection() {
		return direction;
	}

	public void setDirection(Direction direction) {
		this.direction = direction;
	}
}