import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

public interface MovementControl {


    boolean makeMove(Graph graph, PrintWriter cout, BufferedReader cin) throws InvalidInputException, IOException, InterruptedException;

    void checkRegion(Player player);

	boolean validateMoveChoice(Player player, Graph graph);

	void probeMapSurroundings(Player player);

}