import java.util.*;

public class TrafficNetwork {

	private ArrayList<RoadSegment> roads;
	private ArrayList<Intersection> intersections;

	public void checkNumberOfVehiclesInSegment() {
		throw new UnsupportedOperationException();
	}

	public void checkNumberOfVehiclesInLane() {
		throw new UnsupportedOperationException();
	}

	public void checkNumberOfVehiclesAtIntersection() {
		throw new UnsupportedOperationException();
	}

	public void checkNumberOfVehiclesInIntersection() {
		throw new UnsupportedOperationException();
	}

	public ArrayList<RoadSegment> getRoads() {
		return roads;
	}

	public void setRoads(ArrayList<RoadSegment> roads) {
		this.roads = roads;
	}

	public ArrayList<Intersection> getIntersections() {
		return intersections;
	}

	public void setIntersections(ArrayList<Intersection> intersections) {
		this.intersections = intersections;
	}

//	public void makeMap(Graph graph, int x, int y){
//
//		Node node = graph.getNode(x+5, y+9, graph.getAllNodes());
//
//		for (int i = 0; i < 10; i++) {
//			node.setTrafficElement(TrafficElement.LANE);
//			node.setNorth(graph.getNode(node.getPoint().getX(), node.getPoint().getY()-1, graph.getAllNodes()));
//			if (i!=9)node = node.getNorth();
//		}
//		node.setWest(graph.getNode(node.getPoint().getX()-1, node.getPoint().getY(), graph.getAllNodes()));
//		node=node.getWest();
//
//		for (int i = 0; i < 10; i++) {
//			node.setTrafficElement(TrafficElement.LANE);
//			node.setSouth(graph.getNode(node.getPoint().getX(), node.getPoint().getY()+1, graph.getAllNodes()));
//			if (i!=9)node = node.getSouth();
//		}
//		node.setEast(graph.getNode(node.getPoint().getX()+1, node.getPoint().getY(), graph.getAllNodes()));
//
//		node = graph.getNode(0, 5, graph.getAllNodes());
//		for (int i = 0; i < 10; i++) {
//			node.setTrafficElement(TrafficElement.LANE);
//			node.setWest(graph.getNode(node.getPoint().getX()+1, node.getPoint().getY(), graph.getAllNodes()));
//			if (i!=9)node = node.getWest();
//		}
//		node.setNorth(graph.getNode(node.getPoint().getX(), node.getPoint().getY()-1, graph.getAllNodes()));
//		node = node.getNorth();
//
//		for (int i = 0; i < 10; i++) {
//			node.setTrafficElement(TrafficElement.LANE);
//			node.setEast(graph.getNode(node.getPoint().getX()-1, node.getPoint().getY(), graph.getAllNodes()));
//			if (i!=9)node = node.getEast();
//		}
//		node.setSouth(graph.getNode(node.getPoint().getX(), node.getPoint().getY()+1, graph.getAllNodes()));
//
//	}

	/**
	 * Creates a vertical road of length "size" with 2 lanes.
	 * @param size
	 * @param x
	 * @param y
	 * @param graph
	 */
	public void makeVerticalRoad(int size, int x, int y, Graph graph){

		Node node = graph.getNode(x, y, graph.getAllNodes());

		for (int i = 0; i < size; i++) {
			node.setTrafficElement(TrafficElement.LANE);
			node.setNorth(graph.getNode(node.getPoint().getX(), node.getPoint().getY()-1, graph.getAllNodes()));
			if (i!=size-1)node = node.getNorth();
		}
		node.setWest(graph.getNode(node.getPoint().getX()-1, node.getPoint().getY(), graph.getAllNodes()));
		node=node.getWest();

		for (int i = 0; i < size; i++) {
			node.setTrafficElement(TrafficElement.LANE);
			node.setSouth(graph.getNode(node.getPoint().getX(), node.getPoint().getY()+1, graph.getAllNodes()));
			if (i!=size-1)node = node.getSouth();
		}
		node.setEast(graph.getNode(node.getPoint().getX()+1, node.getPoint().getY(), graph.getAllNodes()));
	}

	/**
	 * Creates a horizontal road of length "size" with 2 lanes.
	 * @param size
	 * @param x
	 * @param y
	 * @param graph
	 */
	public void makeHorizontalRoad(int size, int x, int y, Graph graph){
		Node node = graph.getNode(x, y, graph.getAllNodes());

		for (int i = 0; i < size; i++) {
			node.setTrafficElement(TrafficElement.LANE);
			node.setEast(graph.getNode(node.getPoint().getX()+1, node.getPoint().getY(), graph.getAllNodes()));
			if (i!=size-1)node = node.getEast();
		}
		node.setNorth(graph.getNode(node.getPoint().getX(), node.getPoint().getY()-1, graph.getAllNodes()));
		node = node.getNorth();

		for (int i = 0; i < size; i++) {
			node.setTrafficElement(TrafficElement.LANE);
			node.setWest(graph.getNode(node.getPoint().getX()-1, node.getPoint().getY(), graph.getAllNodes()));
			if (i!=size-1)node = node.getWest();
		}
		node.setSouth(graph.getNode(node.getPoint().getX(), node.getPoint().getY()+1, graph.getAllNodes()));
	}


}