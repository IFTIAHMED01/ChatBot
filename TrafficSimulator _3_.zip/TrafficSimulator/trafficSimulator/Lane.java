public class Lane {

	private int length;
	private Direction direction;
	private Point start;

	public Lane(int length, Direction direction, Point start) {
		this.length = length;
		this.direction = direction;
		this.start = start;
	}

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public Direction getDirection() {
		return direction;
	}

	public void setDirection(Direction direction) {
		this.direction = direction;
	}

	public Point getStart() {
		return start;
	}

	public void setStart(Point start) {
		this.start = start;
	}


}