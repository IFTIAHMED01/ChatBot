public abstract class Vehicle {

	private MovementStatus movementStatus;
	private String color;
	private Double size;
	private Double weight;
	private Double maxSpeed;
	private DamageStatus damageStatus;

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public Double getSize() {
		return size;
	}

	public void setSize(Double size) {
		this.size = size;
	}

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	public Double getMaxSpeed() {
		return maxSpeed;
	}

	public void setMaxSpeed(Double maxSpeed) {
		this.maxSpeed = maxSpeed;
	}

	public DamageStatus getDamageStatus() {
		return damageStatus;
	}

	public void setDamageStatus(DamageStatus damageStatus) {
		this.damageStatus = damageStatus;
	}

	public MovementStatus getMovementStatus() {
		return movementStatus;
	}

	public void setMovementStatus(MovementStatus movementStatus) {
		this.movementStatus = movementStatus;
	}
}