import java.util.ArrayList;

public class DamageStatus {

	DamageStatus(){
		this.currentStatus = 100.0;
		this.sufferedDamageHistory = new ArrayList<>();
		this.generatedDamageHistory = new ArrayList<>();
	}

	private Double currentStatus;
	private ArrayList<Double> sufferedDamageHistory;
	private ArrayList<Double> generatedDamageHistory;

	public Double getCurrentDamageStatus() {
		return currentStatus;
	}

	public void updateDamageStatus(Double d) {
		this.currentStatus = currentStatus + d;
	}

	public void calculateSufferedDamage() {
		throw new UnsupportedOperationException();
	}

	public void calculateGenerateDamage() {
		throw new UnsupportedOperationException();
	}

	public Double getCurrentStatus() {
		return currentStatus;
	}

	public void setCurrentStatus(Double currentStatus) {
		this.currentStatus = currentStatus;
	}

	public ArrayList<Double> getSufferedDamageHistory() {
		return sufferedDamageHistory;
	}

	public void setSufferedDamageHistory(ArrayList<Double> sufferedDamageHistory) {
		this.sufferedDamageHistory = sufferedDamageHistory;
	}

	public ArrayList<Double> getGeneratedDamageHistory() {
		return generatedDamageHistory;
	}

	public void setGeneratedDamageHistory(ArrayList<Double> generatedDamageHistory) {
		this.generatedDamageHistory = generatedDamageHistory;
	}
}