import javax.print.attribute.standard.PrinterURI;
import java.net.*;
import java.io.*;
import java.util.ArrayList;

import static java.lang.System.exit;

public class ConnectionThread extends Thread{
    private Socket client1;

    public ConnectionThread(Socket c1) {
        client1=c1;
    }

    public void run() {

        try (
                BufferedReader cin = new BufferedReader(new InputStreamReader(client1.getInputStream()));
                PrintWriter cout = new PrintWriter(client1.getOutputStream(), true);
        ) {

            GameEngine game1 = new GameEngine();
            game1.start();

            Graph graph = new Graph(50, 10);
            TrafficNetwork trafficNetwork = new TrafficNetwork();

            GameEngine.makeMap(graph, trafficNetwork);

            Intersection intersection = new Intersection();
            graph.setAllInterNodes(intersection.addAllInterNodes(graph));

            GameEngine.printRules(cout);

            graph.printMap(10, 50, cout);

            GameEngine.player = new Player(GameEngine.selectVehicle(cout, cin));
            MovementStatus movementStatus = new MovementStatus(new Point(6, 9), null, null);
            GameEngine.player.getVehicle().setMovementStatus(movementStatus);
            GameEngine.player.reputation.setNiceness(0.0);
            Node n = graph.getNode(6, 9, graph.getAllNodes());
            GameEngine.player.getVehicle().getMovementStatus().setPoint(n.getPoint());
            n.setTrafficElement(TrafficElement.VEHICLE);
            DamageStatus damageStatus = new DamageStatus();
            GameEngine.player.getVehicle().setDamageStatus(damageStatus);

            ArrayList<Player> bots = GameEngine.initializeBots(graph);

            graph.printMap(10, 50, cout);

            //xml file reading
//        File map = new File("data.xml");
//        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
//        DocumentBuilder db = dbf.newDocumentBuilder();
//        Document document = db.parse(map);


            while (true) {

                boolean tempBool = true;
                Direction d;

                cout.println("Were here lololoololol");
                d = makeMovementDecision(cin, cout);
                if (d == null) exit(0);

                while(tempBool) {
                    try {
                        tempBool = GameEngine.player.makeMove(graph, cout, cin);
                    } catch (InvalidInputException e) {
                        e.printStackTrace();
                    }
                    GameEngine.moveBots(graph, cout, cin);
                }

                cout.println("Your health: " + GameEngine.player.getVehicle().getDamageStatus().getCurrentStatus());
                cout.println("Your reputation: " + GameEngine.player.reputation.getNiceness());

                // Singleton used here to print the map

                Singleton single = Singleton.getInstance();
                single.printMap(10, 50, graph, cout);

            }
        } catch (IOException e) {
            System.out.println("IO Exception found");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * This method prompts user to make a move and changes lastMove attribute
     * of the player class to selected move.
     *
     * @return Direction(enum) the player chose to move
     * (NORTH, WEST, SOUTH, EAST)
     */
    public Direction makeMovementDecision(BufferedReader cin, PrintWriter cout) throws IOException, InterruptedException {

        String m = "";

        cout.println("Make a move(W, A, S, D): ");
        while (true) {
            try {
                m = cin.readLine();
                if (m.equals("W") || m.equals("A") || m.equals("S") || m.equals("D"))
                    break;
                if (m.equals("quit") || m.equals("QUIT")) return null;
                throw new InvalidInputException("Wrong input");
            } catch (InvalidInputException ex) {
                cout.println("Invalid Input");
            }

        }

        //switch statements that return the selected move
        switch (m) {
            case "W" -> {
                GameEngine.player.setLastMove(Direction.NORTH);

                return Direction.NORTH;
            }
            case "A" -> {
                GameEngine.player.setLastMove(Direction.WEST);
                return Direction.WEST;
            }
            case "S" -> {
                GameEngine.player.setLastMove(Direction.SOUTH);
                return Direction.SOUTH;
            }
            case "D" -> {
                GameEngine.player.setLastMove(Direction.EAST);
                return Direction.EAST;
            }
        }
        return null;
    }
}