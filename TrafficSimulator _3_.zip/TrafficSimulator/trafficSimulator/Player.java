import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

public class Player implements MovementControl {

    private Vehicle vehicle;
    public ArrayList<Direction> moveList;
    public Reputation reputation;
    public Direction lastMove;
    private boolean hasChallenged;

    /**
     * Constructor
     * @param vehicle
     */
    public Player(Vehicle vehicle) {
        this.vehicle = vehicle;
        ArrayList<Direction> moveList = new ArrayList<>();
        this.reputation = new Reputation();
        this.lastMove = null;
        this.hasChallenged = false;
    }

    public ArrayList<Direction> getMoveList() {
        return moveList;
    }

    public void setMoveList(ArrayList<Direction> moveList) {
        this.moveList = moveList;
    }

    public Direction getLastMove() {
        return lastMove;
    }

    public void setLastMove(Direction lastMove) {
        this.lastMove = lastMove;
    }


    /**
     * This method moves the vehicle in the selected direction
     * @param graph
     * @return
     * @throws InvalidInputException
     */
    @Override
    public boolean makeMove(Graph graph, PrintWriter cout, BufferedReader cin) throws InvalidInputException, IOException, InterruptedException {

        Point p = this.vehicle.getMovementStatus().getPoint();
        boolean isBot = graph.getNode(p.getX(), p.getY(), graph.getAllNodes()).getTrafficElement() == TrafficElement.BOT;


        switch (this.lastMove) {
            case NORTH -> {
                int x = p.getX();
                int y = p.getY();

                Node node1 = graph.getNode(x, y, graph.getAllNodes());

                if (graph.getNode(x, y - 1, graph.getAllNodes()) == null) {
                    return iThinkUBoutToCrash(isBot, cout, cin);
                }
                Node node2 = graph.getNode(x, y - 1, graph.getAllNodes());

                if (node2.getTrafficElement() != TrafficElement.LANE && node2.getTrafficElement() != TrafficElement.BOT) {
                    return iThinkUBoutToCrash(isBot, cout, cin);
                }

                if (node2.getTrafficElement() == TrafficElement.BOT) {
                    return true;
                }

                if (node1.getNorth() == null) {
                    if (!hasChallenged)
                        return askToChallenge(graph, isBot, node1, node2, cout, cin);
                }

                this.vehicle.getMovementStatus().setPoint(new Point(x, y - 1));
                return (changeNode(graph, isBot, node1, node2));
            }
            case WEST -> {
                int x = p.getX();
                int y = p.getY();

                Node node1 = graph.getNode(x, y, graph.getAllNodes());

                if (graph.getNode(x - 1, y, graph.getAllNodes()) == null) {
                    return iThinkUBoutToCrash(isBot, cout, cin);
                }

                Node node2 = graph.getNode(x - 1, y, graph.getAllNodes());

                if (node2.getTrafficElement() != TrafficElement.LANE && node2.getTrafficElement() != TrafficElement.BOT) {
                    return iThinkUBoutToCrash(isBot, cout, cin);
                }

                if (node1.getWest() == null) {
                    if (!hasChallenged)
                        return askToChallenge(graph, isBot, node1, node2, cout, cin);
                }

                this.vehicle.getMovementStatus().setPoint(new Point(x - 1, y));
                return (changeNode(graph, isBot, node1, node2));
            }
            case SOUTH -> {
                int x = p.getX();
                int y = p.getY();

                Node node1 = graph.getNode(x, y, graph.getAllNodes());

                if (graph.getNode(x, y + 1, graph.getAllNodes()) == null) {
                    return iThinkUBoutToCrash(isBot, cout, cin);
                }

                Node node2 = graph.getNode(x, y + 1, graph.getAllNodes());

                if (node2.getTrafficElement() != TrafficElement.LANE && node2.getTrafficElement() != TrafficElement.BOT) {
                    return iThinkUBoutToCrash(isBot, cout, cin);
                }

                if (node1.getSouth() == null) {
                    if (!hasChallenged)
                        return askToChallenge(graph, isBot, node1, node2, cout, cin);
                }

                this.vehicle.getMovementStatus().setPoint(new Point(x, y + 1));
                return (changeNode(graph, isBot, node1, node2));
            }
            case EAST -> {
                int x = p.getX();
                int y = p.getY();

                Node node1 = graph.getNode(x, y, graph.getAllNodes());

                if (graph.getNode(x + 1, y, graph.getAllNodes()) == null) {
                    return iThinkUBoutToCrash(isBot, cout, cin);
                }

                Node node2 = graph.getNode(x + 1, y, graph.getAllNodes());

                if (node2.getTrafficElement() != TrafficElement.LANE && node2.getTrafficElement() != TrafficElement.BOT) {
                    return iThinkUBoutToCrash(isBot, cout, cin);
                }

                if (node1.getEast() == null) {
                    if (!hasChallenged)
                        return askToChallenge(graph, isBot, node1, node2, cout, cin);
                }

                this.vehicle.getMovementStatus().setPoint(new Point(x + 1, y));
                return (changeNode(graph, isBot, node1, node2));
            }
        }

        return false;
    }

    @Override
    public void checkRegion(Player player) {

    }

    @Override
    public boolean validateMoveChoice(Player player, Graph graph) {
        return false;
    }

    @Override
    public void probeMapSurroundings(Player player) {

    }

    /**
     * This prompts user to continue or brake in case the vehicle is about to crash
     * @param isBot
     * @return
     */
    private boolean iThinkUBoutToCrash(boolean isBot, PrintWriter cout, BufferedReader cin) throws IOException, InterruptedException {
        if (isBot) {
            GameEngine.player.getVehicle().getDamageStatus().updateDamageStatus(-33.0);
            cout.println("Bot crashed with you.");
            if (GameEngine.player.getVehicle().getDamageStatus().getCurrentStatus() < 0.0)
                System.exit(0);
            return false;
        } else {
            cout.println("You're about to crash, press Y to continue or N to brake!");
            String c = askYN(cout, cin);
            if (c.equals("Y")) {
                GameEngine.player.getVehicle().getDamageStatus().updateDamageStatus(-33.0);
                cout.println("Bot crashed with you.");
                if (GameEngine.player.getVehicle().getDamageStatus().getCurrentStatus() < 0.0)
                    System.exit(0);
            }
        }
        return false;
    }

    /**
     * Changes node1 to lane and node2 to player.vehicle
     * @param graph
     * @param isBot
     * @param node1
     * @param node2
     * @return
     */
    private boolean changeNode(Graph graph, boolean isBot, Node node1, Node node2) {
        node1.setVehicle(null);
        node1.setTrafficElement(TrafficElement.LANE);
        node2.setVehicle(this.vehicle);
        if (!isBot) node2.setTrafficElement(TrafficElement.VEHICLE);
        if (isBot) node2.setTrafficElement(TrafficElement.BOT);

        if (isBot) return true;

        return !graph.getAllInterNodes().contains(node2);    //returns true if node2 is an intersection node so that the while loop
        //breaks. i.e., vehicle stops moving forward
    }

    /**
     * Asks user if they want to challenge or not.
     * And executes challenge if the player selects to do so
     * @param graph
     * @param isBot
     * @param node1
     * @param node2
     * @return
     * @throws InvalidInputException
     */
    public boolean askToChallenge(Graph graph, boolean isBot, Node node1, Node node2, PrintWriter cout, BufferedReader cin) throws InvalidInputException, IOException, InterruptedException {

        Thread.sleep(100);
        cout.println("You're about to make a wrong move, enter Y to challenge or N to cancel");
        String c = askYN(cout, cin);

        this.hasChallenged = false;

        if (c.equals("N")) {
            return false;
        }
        if (c.equals("Y")) {
            this.hasChallenged = true;
        }

        if (isBot) return false;

        // Local class that creates a challenge handler object
        class ChallengeHandler {

            final Graph graph;
            final Node node1;
            final Node node2;

            ChallengeHandler(Graph mgraph, Node mnode1, Node mnode2) {
                graph = mgraph;
                node1 = mnode1;
                node2 = mnode2;
            }


            /**
             * checks if there is any crash or not.
             * If the crash happens, it reduces the reputation by 2 otherwise increases it by 1
             * @param graph
             * @return
             * @throws InvalidInputException
             */
            public double handleThis(Graph graph) throws InvalidInputException, IOException, InterruptedException {
                Graph dummyGraph = new Graph(graph);
                makeMove(dummyGraph, cout, cin);
                if (GameEngine.moveBots(dummyGraph, cout, cin)) {
                    return -2.0;
                }
                return 1.0;
            }

        }


        // Initializing a challengeHandler object of the local class
        ChallengeHandler challengeHandler = new ChallengeHandler(graph, node1, node2);
        Double rep = challengeHandler.handleThis(graph);

        // changing reputation
        this.reputation.addReputationHistory(rep);
        this.reputation.setNiceness(this.reputation.getNiceness() + rep);

        // If reputation goes below 0, Game Over.
        if (this.reputation.getNiceness() < 0.0) {
            cout.println("Game Over.");
            System.exit(0);
        }

        // Otherwise...
        if (rep > 0) {
            changeNode(graph, false, node1, node2);
            cout.println("You didn't crash, your reputation is now " + this.reputation.getNiceness());
        } else {
            cout.println("You just crashed. Your reputation is now " + this.reputation.getNiceness());
        }

        this.hasChallenged = false;

        return false;

    }


    /**
     * Method to ask player to input Y or N
     * @return
     */
    private String askYN(PrintWriter cout, BufferedReader cin) throws IOException, InterruptedException {
        String c = "X";

        Thread.sleep(100);

        while (cin.ready()) {
            c = cin.readLine();
            if (c.equals("Y") || c.equals("N")) {
                break;
            }
            try {
                throw new InvalidInputException("Invalid move");
            } catch (InvalidInputException e) {
                cout.println("Invalid Input");
            }
        }
        return c;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

}