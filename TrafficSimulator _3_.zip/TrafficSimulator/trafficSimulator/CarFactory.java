public class CarFactory implements VehicleFactory{
    @Override
    public String getColor() {
        return null;
    }

    @Override
    public void setColor(String color) {

    }

    @Override
    public Double getSize() {
        return null;
    }

    @Override
    public void setSize(Double size) {

    }

    @Override
    public Double getWeight() {
        return null;
    }

    @Override
    public void setWeight(Double weight) {

    }

    @Override
    public Double getMaxSpeed() {
        return null;
    }

    @Override
    public void setMaxSpeed(Double maxSpeed) {

    }

    @Override
    public DamageStatus getDamageStatus() {
        return null;
    }

    @Override
    public void setDamageStatus(DamageStatus damageStatus) {

    }

    @Override
    public MovementStatus getMovementStatus() {
        return null;
    }

    @Override
    public void setMovementStatus(MovementStatus movementStatus) {

    }
}
