import java.util.ArrayList;

public class Reputation {

	public Reputation(){
		this.niceness = 0.0;
		this.reputationHistory = new ArrayList<Double>();
	}

	private Double niceness;
	private ArrayList<Double> reputationHistory;

	public Double getNiceness() {
		return niceness;
	}

	public void setNiceness(Double niceness) {
		this.niceness = niceness;
	}

	public ArrayList<Double> getReputationHistory() {
		return reputationHistory;
	}

	public void addReputationHistory(Double rep) {
		this.reputationHistory.add(rep);
	}
}