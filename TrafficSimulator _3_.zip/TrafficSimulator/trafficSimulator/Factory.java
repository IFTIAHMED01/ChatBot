import java.util.SortedMap;

public class Factory {

    public Direction getMove(Direction d){
        if (d == null){
            return null;
        }
        if (d == Direction.EAST){
            return Direction.EAST;
        }
        else if (d == Direction.NORTH){
            return Direction.NORTH;
        }
        else if(d == Direction.WEST){
            return Direction.WEST;
        }
        else if (d == Direction.SOUTH){
            return Direction.SOUTH;
        }

        return null;
    }

}
