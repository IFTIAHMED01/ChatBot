// COSC 2P95 - Lab Exercise 09
//
// Name: Akshar Patel
// Student #: 6581599
//
// Submitted to Earl Foxwell at Brock University


#include <iostream>
#include <unistd.h>
#include <cstdlib>
#include <csignal>
#include <pthread.h>
#include <cmath>

static int NUMTHREADS = 0;
volatile bool continuing;
volatile int occupied;
pthread_mutex_t lock; //Our mutual exclusion lock
float LOWEST = 99999999.0f;
float X_lowest;
float Y_lowest;


//method returns min if value is less than min value and max if value is greater than max value
//returns value if it is within the range
float clamp(float x, float min, float max) {
    if (x < min) return min;
    else if (x > max) return max;
    else return x;
}


// inputs the values of x and y in the function and returns the result
float math(float x, float y) {
    return (-(y + 47) * std::sin(std::sqrt(std::abs((x / 2) + y + 47)))) -
           (x * std::sin(std::sqrt(std::abs(x - y - 47))));
}


// Method handles the climbers
// generates 4 random values for x and y and checks if the lowest value is lower than the global min
void *climb(void *unnecessary) {

    float temp_value = 0.0; // this stores the value returned by math function for one of the values
    float temp_lowest_value = 999999.0f; // stores the lowest value of four selected
    float temp_x = 0.0; // stores x value for current processing value
    float temp_y = 0.0; // stores y value for current processing value
    float temp_lowest_x = 0.0; // stores x for lowest value of four
    float temp_lowest_y = 0.0; // stores x for lowest value of four

    // generating a random x and y
    float curr_x = (-512.0f) + (float(rand()) / (float) RAND_MAX) * 1024.0f;
    float curr_y = (-512.0f) + (float(rand()) / (float) RAND_MAX) * 1024.0f;;
    while (continuing) {
        // generates 4 random values for x and y nearby the current values of x and y
        for (int i = 0; i < 4; ++i) {

            //generating a random value between -5.0 and 5.0
            float random_x = (-5.0f) + (float(rand()) / (float) RAND_MAX) * 10.0f;;
            float random_y = (-5.0f) + (float(rand()) / (float) RAND_MAX) * 10.0f;;

            // adding a random value between -5.0 amd 5.0
            temp_x = curr_x + random_x;
            temp_y = curr_y + random_y;

            // storing the value in temp_x and temp_y
            temp_x = clamp(temp_x, -512.0, 512.0);
            temp_y = clamp(temp_y, -512.0, 512.0);

            temp_value = math(temp_x, temp_y); // calling the function for that x and y

            // storing the lowest value of four on the variables initialized above
            if (temp_value < temp_lowest_value) {
                temp_lowest_value = temp_value;
                temp_lowest_x = temp_x;
                temp_lowest_y = temp_y;
            }
        }

        // if the lowest of the four is lower than value for current x and y, then changing current x and y
        if (temp_lowest_value < math(curr_x, curr_y)) {
            curr_x = temp_lowest_x;
            curr_y = temp_lowest_y;
        }

        // checking if the LOWEST value overall is higher than the selected lowest value in current thread
        // and if the value is lower than LOWEST value overall, then changing the LOWEST value to new lowest value of current thread
        pthread_mutex_lock(&lock);
        if (math(curr_x, curr_y) < LOWEST) {
            LOWEST = math(curr_x, curr_y);
            X_lowest = curr_x;
            Y_lowest = curr_y;
        }
        occupied--;
        pthread_mutex_unlock(&lock);
    }
}

void peek(int sig) {
    std::cout << "Currently processing: " << (continuing ? "Yes" : "No") << std::endl;
}

//We don't really care what 'sig' is for this example
void interrupted(int sig) {
    std::cout << "\nComputations complete.\nHalting now..." << std::endl;
    continuing = false;
    std::cout << "Best Height: " << LOWEST << std::endl;
    std::cout << "x: " << X_lowest << "\t" << "Y: " << Y_lowest << std::endl;
    exit(0);
}


int main() {

    srand(time(NULL));

    std::cout << "Enter number of threads(0-8). Enter 0 to quit." << std::endl;
    std::cin >> NUMTHREADS;

    pthread_t ct[NUMTHREADS];//our child threads
    continuing = true;
    std::cout << "About to commence; PID: " << getpid() << std::endl;

    while (true) {
        if (signal(SIGINT, interrupted) == SIG_ERR) {
            std::cout << "Unable to change signal handler." << std::endl;
            return 1;
        }
        if (signal(SIGUSR1, peek) == SIG_ERR) {
            std::cout << "Unable to change signal handler." << std::endl;
            return 1;
        }

        if (NUMTHREADS == 0){
            return 0;
        }
        else {
            continuing = true;
            for (int i = 0; i < NUMTHREADS; i++) {
                pthread_mutex_lock(&lock);//reserve lock
                pthread_create(&ct[i], NULL, &climb, NULL); // creating climbers
                occupied++;
                pthread_mutex_unlock(&lock);//release lock
            }
            while (occupied > 0)
                sleep(1);
        }
    }
}