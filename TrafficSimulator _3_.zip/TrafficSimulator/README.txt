To run this program, you must have the latest JDK (17+) installed in your computer.

Instructions to compile and run this code on your computer through command line.
1. Navigate to "trafficSimulator" directory in your computer.
2. Type "javac Main.java" to compile
3. Type "java ThreadedServer" to run the server
4. Type "java Client" to run the client
5. Go easy on marking as some of the assignment requirements were "Abstract"